-- MySQL dump 10.13  Distrib 5.5.11, for Linux (x86_64)
--
-- Host: localhost    Database: h1265_ddb
-- ------------------------------------------------------
-- Server version	5.5.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbl_banners`
--

DROP TABLE IF EXISTS `tbl_banners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_banners` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_image` varchar(255) NOT NULL,
  `id_sort` int(10) unsigned NOT NULL,
  `id_position` int(10) unsigned NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `link` varchar(255) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_banners`
--

LOCK TABLES `tbl_banners` WRITE;
/*!40000 ALTER TABLE `tbl_banners` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_banners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_bug_messages`
--

DROP TABLE IF EXISTS `tbl_bug_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_bug_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_bug` int(10) unsigned NOT NULL,
  `id_user` int(10) unsigned NOT NULL,
  `time` int(10) unsigned NOT NULL,
  `text` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=113 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_bug_messages`
--

LOCK TABLES `tbl_bug_messages` WRITE;
/*!40000 ALTER TABLE `tbl_bug_messages` DISABLE KEYS */;
INSERT INTO `tbl_bug_messages` VALUES (103,34,41,1386654600,'Статус изменен на \"Готово\"'),(104,33,41,1386654609,'Статус изменен на \"Готово\"'),(105,35,1,1386655191,'Статус изменен на \"В работе\"'),(106,35,1,1386655205,'Нужно связаться с верстальщиком'),(107,35,1,1386655221,'Статус изменен на \"Готово\"'),(108,35,41,1386655261,'Статус изменен на \"Закрыто\"'),(109,34,41,1386655279,'Статус изменен на \"Закрыто\"'),(110,33,41,1386655297,'Статус изменен на \"Закрыто\"'),(111,37,1,1387177478,'Статус изменен на \"Готово\"'),(112,36,1,1387177499,'Статус изменен на \"Готово\"');
/*!40000 ALTER TABLE `tbl_bug_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_bugs`
--

DROP TABLE IF EXISTS `tbl_bugs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_bugs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `id_priority` int(10) unsigned NOT NULL,
  `id_state` int(10) unsigned NOT NULL,
  `description` text NOT NULL,
  `reply` text NOT NULL,
  `id_user` varchar(45) NOT NULL,
  `time_detected` int(10) unsigned NOT NULL,
  `time_done` int(10) unsigned NOT NULL,
  `id_type` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_bugs`
--

LOCK TABLES `tbl_bugs` WRITE;
/*!40000 ALTER TABLE `tbl_bugs` DISABLE KEYS */;
INSERT INTO `tbl_bugs` VALUES (33,'Убрать листалку','http://dbg2.deka-web.ru/contacts',0,30,'Убрать листалку с этой страницы. И сделать так, чтобы показ листалки на обычных страницах настраивался.','','41',1386619200,1386655297,0),(34,'Баннеры в правую колонку','http://dbg2.deka-web.ru/cp/banners/admin/admin',0,30,'','','41',1386619200,1386655279,1),(35,'Сделать резину','http://dbg2.deka-web.ru',1,30,'','','41',1386619200,1386655261,0),(36,'миниатюры плохо работают','http://dbg2.deka-web.ru',0,20,'','','41',1387137600,0,0),(37,'на витрине не краткое описание а название','http://dbg2.deka-web.ru',0,20,'','','41',1387137600,0,0);
/*!40000 ALTER TABLE `tbl_bugs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_feedback`
--

DROP TABLE IF EXISTS `tbl_feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_feedback` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tst_create` int(10) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `flg_new` tinyint(1) unsigned NOT NULL,
  `flg_phonecall` int(11) NOT NULL,
  `phone` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_feedback`
--

LOCK TABLES `tbl_feedback` WRITE;
/*!40000 ALTER TABLE `tbl_feedback` DISABLE KEYS */;
INSERT INTO `tbl_feedback` VALUES (17,1386576890,'Превед','tishurin@yandex.ru','',0,0,''),(18,1386577412,'Дмитрий','tishurin@yandex.ru','Мое сообщение - можно ли то-то',0,0,'123-23-23'),(19,1386577463,'Дмитрий','tishurin@yandex.ru','Мое сообщение - можно ли то-то',0,0,'123-23-23'),(20,1386577481,'Дмитрий','tishurin@yandex.ru','Мое сообщение - можно ли то-то',0,0,'123-23-23'),(21,1386577524,'Дмитрий','tishurin@yandex.ru','Мое сообщение - можно ли то-то',0,0,'123-23-23'),(22,1386579929,'Дмитрий','','',0,1,'926-355-96-83');
/*!40000 ALTER TABLE `tbl_feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_files`
--

DROP TABLE IF EXISTS `tbl_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_files` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `source` varchar(255) NOT NULL,
  `tst_upload` int(10) unsigned NOT NULL,
  `flg_folder` int(10) unsigned NOT NULL,
  `id_parent` int(10) unsigned NOT NULL,
  `flg_image` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_files`
--

LOCK TABLES `tbl_files` WRITE;
/*!40000 ALTER TABLE `tbl_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_pages_files`
--

DROP TABLE IF EXISTS `tbl_pages_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_pages_files` (
  `id_page` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_file` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id_page`,`id_file`)
) ENGINE=MyISAM AUTO_INCREMENT=105 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_pages_files`
--

LOCK TABLES `tbl_pages_files` WRITE;
/*!40000 ALTER TABLE `tbl_pages_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_pages_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_users`
--

DROP TABLE IF EXISTS `tbl_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `url_role` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `login` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `salt` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `flg_active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=44 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_users`
--

LOCK TABLES `tbl_users` WRITE;
/*!40000 ALTER TABLE `tbl_users` DISABLE KEYS */;
INSERT INTO `tbl_users` VALUES (1,'root','Дмитрий','root','6e047c439ea6860ace82c6ab7df718de','32ae28982e674c71fb57a1235f880350','',1),(41,'root','Виталий','vvt','c4510c1b4a0156f462f49aaf99f5538b','f6aded2be46c3e603d22f7702a82a1c8','',1),(42,'administrator','abiton','abiton','5edcdc7a4ef85d271fc951ae3211ab98','d801bf9597fa03eb5a3bf53f5ed3e764','abiton@yandex.ru',1),(43,'administrator','Admin','admin','2a681a6e93b30e2ec0a4da5a131830c7','be51c4df0f337bfbca1d0690ae9b525c','nsherbina@nucrf.ru',1);
/*!40000 ALTER TABLE `tbl_users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-05-08 10:21:24
