-- MySQL dump 10.13  Distrib 5.5.33, for osx10.6 (i386)
--
-- Host: localhost    Database: dw_abiton_1_dlp
-- ------------------------------------------------------
-- Server version	5.5.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbl_banners`
--

DROP TABLE IF EXISTS `tbl_banners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_banners` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_image` varchar(255) NOT NULL,
  `id_sort` int(10) unsigned NOT NULL,
  `id_position` int(10) unsigned NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `link` varchar(255) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_banners`
--

LOCK TABLES `tbl_banners` WRITE;
/*!40000 ALTER TABLE `tbl_banners` DISABLE KEYS */;
INSERT INTO `tbl_banners` VALUES (23,'16',4,0,'Название представленного продукта или услуги','#','Краткое описание продукта, или услуги, или еще чего-нибудь. Пишется мелким шрифтом. Здесь писать много не надо.'),(25,'17',2,0,'Название представленного продукта','google.ru','Краткое описание продукта, или услуги, или еще чего-нибудь. Пишется мелким шрифтом. Здесь писать много не надо.');
/*!40000 ALTER TABLE `tbl_banners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_feedback`
--

DROP TABLE IF EXISTS `tbl_feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_feedback` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tst_create` int(10) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `flg_new` tinyint(1) unsigned NOT NULL,
  `flg_phonecall` int(11) NOT NULL,
  `phone` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_feedback`
--

LOCK TABLES `tbl_feedback` WRITE;
/*!40000 ALTER TABLE `tbl_feedback` DISABLE KEYS */;
INSERT INTO `tbl_feedback` VALUES (17,1386576890,'Превед','tishurin@yandex.ru','',0,0,''),(18,1386577412,'Дмитрий','tishurin@yandex.ru','Мое сообщение - можно ли то-то',0,0,'123-23-23'),(19,1386577463,'Дмитрий','tishurin@yandex.ru','Мое сообщение - можно ли то-то',0,0,'123-23-23'),(20,1386577481,'Дмитрий','tishurin@yandex.ru','Мое сообщение - можно ли то-то',0,0,'123-23-23'),(21,1386577524,'Дмитрий','tishurin@yandex.ru','Мое сообщение - можно ли то-то',0,0,'123-23-23'),(22,1386579929,'Дмитрий','','',0,1,'926-355-96-83');
/*!40000 ALTER TABLE `tbl_feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_files`
--

DROP TABLE IF EXISTS `tbl_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_files` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `source` varchar(255) NOT NULL,
  `tst_upload` int(10) unsigned NOT NULL,
  `flg_folder` int(10) unsigned NOT NULL,
  `id_parent` int(10) unsigned NOT NULL,
  `flg_image` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_files`
--

LOCK TABLES `tbl_files` WRITE;
/*!40000 ALTER TABLE `tbl_files` DISABLE KEYS */;
INSERT INTO `tbl_files` VALUES (11,'160.jpg','6/52a56d280e89f',1386573096,0,0,1),(12,'bears-42.jpg','6/52a56fccb344d',1386573772,0,0,1),(13,'elephants-11.jpg','8/52a580841ac54',1386578052,0,0,1),(14,'elks-1.jpg','8/52a581ae5202a',1386578350,0,0,1),(15,'tigers-39.jpg','8/52a58208ccef5',1386578440,0,0,1),(16,'raccoons-7.jpg','8/52a58b622becb',1386580834,0,0,1),(17,'259.png','8/52a58d09ada98',1386581257,0,0,1);
/*!40000 ALTER TABLE `tbl_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_pages`
--

DROP TABLE IF EXISTS `tbl_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_parent` int(10) unsigned NOT NULL,
  `id_sort` int(10) unsigned NOT NULL,
  `id_image` int(11) NOT NULL,
  `tst_create` int(10) unsigned NOT NULL,
  `tst_update` int(10) unsigned NOT NULL,
  `flg_public` int(10) unsigned NOT NULL,
  `flg_folder` int(10) unsigned NOT NULL,
  `url` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `template` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `description` text NOT NULL,
  `content` text NOT NULL,
  `areas` text NOT NULL,
  `flg_block_header` int(10) unsigned NOT NULL,
  `flg_block_text` int(10) unsigned NOT NULL,
  `flg_markdown` int(10) unsigned NOT NULL,
  `flg_menu` int(11) NOT NULL,
  `flg_index` int(11) NOT NULL,
  `flg_show_news` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=81 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_pages`
--

LOCK TABLES `tbl_pages` WRITE;
/*!40000 ALTER TABLE `tbl_pages` DISABLE KEYS */;
INSERT INTO `tbl_pages` VALUES (72,0,10,0,1386536400,1386581964,1,0,'about','О компании','','[default]','','','<p>\r\n	    «Война и мир», самый известный роман Л.Н.Толстого, как никакое другое произведение писателя, отражает глубину его мироощущения ссылка и философии. Эта книга ссылка при наведении, потому что она обо всем — о жизни и смерти, о любви и чести, о мужестве и героизме, о славе и подвиге, о войне и мире.\r\n</p>\r\n<h1>Заголовок Н1</h1>\r\n<p>\r\n	 <img src=\"/assets/files/8/52a58208ccef5_page.jpg\" style=\"width: 164px; float: left; margin: 0px 10px 10px 0px;\" alt=\"\">\r\n</p>\r\n<p>\r\n	    В книгу вошли первый и второй тома романа. «Война и мир», самый известный роман Л.Н.Толстого, как никакое другое произведение писателя, отражает глубину его мироощущения и философии. Эта книга из разряда вечных, потому что она обо всем — о жизни и смерти, о любви и чести, о мужестве и героизме, о славе и подвиге, о войне и мире.«Война и мир», самый известный роман Л.Н.Толстого, как никакое другое произведение писателя, отражает глубину его мироощущения и философии. Эта книга из разряда вечных, потому что она обо всем — о жизни и смерти, о любви и чести, о мужестве и героизме, о славе и подвиге, о войне и мире.\r\n</p>\r\n<h2>Заголовок Н2</h2>\r\n<p>\r\n	 <img src=\"/assets/files/8/52a581ae5202a_page.jpg\" style=\"width: 219px; float: right; margin: 0px 0px 10px 10px;\" alt=\"\">\r\n</p>\r\n<p>\r\n	    «Война и мир», самый известный роман Л.Н.Толстого, как никакое другое произведение писателя, отражает глубину его мироощущения и философии. Эта книга из разряда вечных, потому что она обо всем\r\n</p>\r\n<h3>Заголовок Н3</h3>\r\n<p>\r\n	    «Война и мир», самый известный роман Л.Н.Толстого, как никакое другое произведение писателя, отражает глубину его мироощущения и философии. Эта книго войне и мире.\r\n</p>\r\n<p>\r\n	    «Война и мир», самый известный роман Л.Н.Толстого, как никакое другое произведение писателя, отражает глубину его мироощущения и философии. Эта книга из разряда вечных, потому что она обо всем — о жизни и смерти, о любви и чести, о мужестве и героизме, о славе и подвиге, о войне и мире.\r\n</p>\r\n<p>\r\n	    Маркированный список:\r\n</p>\r\n<ul>\r\n	<li>«Война и мир», самый известный роман Л.Н.Толстого, как никакое другое произведение писателя, отражает глубину его мироощущения и философии. Эта книга из разряда вечных</li>\r\n	<li>«Война и мир», самый известный роман Л.Н.Толстого, как никакое другое произведение писателя, отражает глубину его мироощущения и философии</li>\r\n	<li>«Война и мир», самый известный роман Л.Н.Толстого, как никакое</li>\r\n</ul>\r\n<table>\r\n<thead>\r\n<tr>\r\n	<td class=\"left\">\r\n		    Шапка\r\n	</td>\r\n	<td class=\"center\">\r\n		    Столбец\r\n	</td>\r\n	<td class=\"center\">\r\n		    Столбец\r\n	</td>\r\n	<td class=\"center\">\r\n		    Столбец\r\n	</td>\r\n</tr>\r\n</thead>\r\n<tbody>\r\n<tr>\r\n	<th class=\"left\">\r\n		    Заголовок состоящий из 2-х строк\r\n	</th>\r\n	<td class=\"center\">\r\n		    Ячейка состоящая из 2-х строк\r\n	</td>\r\n	<td class=\"center\">\r\n		    Ячейка состоящая из 2-х строк\r\n	</td>\r\n	<td class=\"center\">\r\n		    Ячейка состоящая из 2-х строк\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<th class=\"left\">\r\n		    Заголовок строки\r\n	</th>\r\n	<td class=\"center\">\r\n		    Ячейка\r\n	</td>\r\n	<td class=\"center\">\r\n		    Ячейка\r\n	</td>\r\n	<td class=\"center\">\r\n		    Ячейка\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<th class=\"left\">\r\n		    Заголовок строки\r\n	</th>\r\n	<td class=\"center\">\r\n		    Ячейка\r\n	</td>\r\n	<td class=\"center\">\r\n		    Ячейка\r\n	</td>\r\n	<td class=\"center\">\r\n		    Ячейка\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>\r\n	    Нумерованный список:\r\n</p>\r\n<ol>\r\n	<li>«Война и мир», самый известный роман Л.Н.Толстого, как никакое другое произведение писателя,</li>\r\n	<li>«Война и мир», самый известный роман Л.Н.Толстого, как никакое другое произведение писателя, отражает глубину его мироощущения и философии</li>\r\n</ol>','',0,0,0,1,0,0),(69,0,4,0,1375214400,1386575736,1,1,'news','Новости','news','viewNews','','','','',0,0,0,1,0,1),(70,69,4,0,1375214400,1386574590,1,0,'pervaya_novost','Первая новость','','[default]','','Прошла государственную сертификацию первая защитная система безопасности информации.','<p>\r\n	Прошла государственную сертификацию новая защитная система безопасности информации. Прошла государственную сертификацию новая защитная система безопасности информации.  Прошла государственную сертификацию новая защитная система безопасности информации.\r\n</p>','',0,0,0,0,0,1),(71,69,2,0,1375214400,1386574565,1,0,'vtoraya_novost','Вторая новость','','[default]','','Прошла государственную сертификацию новая защитная система безопасности информации.','<p>\r\n	Прошла государственную сертификацию новая защитная система безопасности информации. Прошла государственную сертификацию новая защитная система безопасности информации.  Прошла государственную сертификацию новая защитная система безопасности информации.\r\n</p>','',0,0,0,0,0,1),(76,74,2,0,1386536400,1386571882,1,0,'pervaya_yslyga','Первая услуга','','[default]','','','','',0,0,0,1,0,1),(73,0,8,0,1386536400,1386573023,1,1,'products','Продукты','','[default]','','','','',0,0,0,1,0,1),(74,0,6,0,1386536400,1386571335,1,1,'services','Услуги','','[default]','','','','',0,0,0,1,0,1),(75,0,2,0,1386536400,1386576024,1,0,'contacts','Контакты','contacts','[default]','','','<p>\r\n	 ЗАО \"Абитон\" всегда к Вашим услугам, звоните в любое время!\r\n</p>','',0,0,0,1,0,1),(77,74,4,0,1386536400,1386571891,1,0,'vtoraya_yslyga','Вторая услуга','','[default]','','','','',0,0,0,1,0,1),(78,0,12,0,1386536400,1386572618,1,0,'index','Главная страница','index','[default]','','','								<h1>О компании</h1>\r\n								<p>«Война и мир», самый известный роман Л.Н.Толстого, как никакое другое произведение писателя, отражает глубину его мироощущения ссылка и философии. Эта книга ссылка при наведении, потому что она обо всем — о жизни и смерти, о любви и чести, о мужестве и героизме, о славе и подвиге, о войне и мире.</p>\r\n								<h1>Заголовок Н1</h1>\r\n								<p>В книгу вошли первый и второй тома романа. «Война и мир», самый известный роман Л.Н.Толстого, как никакое другое произведение писателя, отражает глубину его мироощущения и философии. Эта книга из разряда вечных, потому что она обо <a href=\"images/temp/image.jpg\" class=\"fancybox\" rel=\"gallery\"><img src=\"images/temp/267x155.png\" class=\"right\"></a>всем — о жизни и смерти, о любви и чести, о мужестве и героизме, о славе и подвиге, о войне и мире.«Война и мир», самый известный роман Л.Н.Толстого, как никакое другое произведение писателя, отражает глубину его мироощущения и философии. Эта книга из разряда вечных, потому что она обо всем — о жизни и смерти, о любви и чести, о мужестве и героизме, о славе и подвиге, о войне и мире.</p>\r\n								<a href=\"images/temp/image.jpg\" class=\"fancybox\" rel=\"gallery\"><img src=\"images/temp/155x267.png\" class=\"left\"></a>\r\n								<h2>Заголовок Н2</h2>\r\n								<p>«Война и мир», самый известный роман Л.Н.Толстого, как никакое другое произведение писателя, отражает глубину его мироощущения и философии. Эта книга из разряда вечных, потому что она обо всем</p>\r\n								<h3>Заголовок Н3</h3>\r\n								<p>«Война и мир», самый известный роман Л.Н.Толстого, как никакое другое произведение писателя, отражает глубину его мироощущения и философии. Эта книго войне и мире.</p>\r\n								<p>«Война и мир», самый известный роман Л.Н.Толстого, как никакое другое произведение писателя, отражает глубину его мироощущения и философии. Эта книга из разряда вечных, потому что она обо всем — о жизни и смерти, о любви и чести, о мужестве и героизме, о славе и подвиге, о войне и мире.</p>\r\n								<p>Маркированный список:</p>\r\n								<ul>\r\n									<li>«Война и мир», самый известный роман Л.Н.Толстого, как никакое другое произведение писателя, отражает глубину его мироощущения и философии. Эта книга из разряда вечных</li>\r\n									<li>«Война и мир», самый известный роман Л.Н.Толстого, как никакое другое произведение писателя, отражает глубину его мироощущения и философии</li>\r\n									<li>«Война и мир», самый известный роман Л.Н.Толстого, как никакое</li>\r\n								</ul>\r\n								<table>\r\n									<thead>\r\n										<tr>\r\n											<td class=\"left\">Шапка</td>\r\n											<td class=\"center\">Столбец</td>\r\n											<td class=\"center\">Столбец</td>\r\n											<td class=\"center\">Столбец</td>\r\n										</tr>\r\n									</thead>\r\n									<tbody>\r\n										<tr>\r\n											<th class=\"left\">Заголовок состоящий из 2-х строк</th>\r\n											<td class=\"center\">Ячейка состоящая из 2-х строк</td>\r\n											<td class=\"center\">Ячейка состоящая из 2-х строк</td>\r\n											<td class=\"center\">Ячейка состоящая из 2-х строк</td>\r\n										</tr>\r\n										<tr>\r\n											<th class=\"left\">Заголовок строки</th>\r\n											<td class=\"center\">Ячейка</td>\r\n											<td class=\"center\">Ячейка</td>\r\n											<td class=\"center\">Ячейка</td>\r\n										</tr>\r\n										<tr>\r\n											<th class=\"left\">Заголовок строки</th>\r\n											<td class=\"center\">Ячейка</td>\r\n											<td class=\"center\">Ячейка</td>\r\n											<td class=\"center\">Ячейка</td>\r\n										</tr>\r\n									</tbody>\r\n								</table>\r\n								<p>Нумерованный список:</p>\r\n								<ol>\r\n									<li>«Война и мир», самый известный роман Л.Н.Толстого, как никакое другое произведение писателя,</li>\r\n									<li>«Война и мир», самый известный роман Л.Н.Толстого, как никакое другое произведение писателя, отражает глубину его мироощущения и философии</li>\r\n								</ol>','',0,0,0,0,0,1),(79,73,2,11,1386536400,1386573536,1,0,'mcafee_system_protection','McAfee System Protection','','[default]','','Сертифицированный для отечественного использования McAfee System Protection','','',0,0,0,0,1,1),(80,73,4,12,1386536400,1386573772,1,0,'mcafee_mobile_security','McAfee Mobile Security','','[default]','','Сертифицированный McAfee® Mobile Security','','',0,0,0,0,1,1);
/*!40000 ALTER TABLE `tbl_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_pages_files`
--

DROP TABLE IF EXISTS `tbl_pages_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_pages_files` (
  `id_page` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_file` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id_page`,`id_file`)
) ENGINE=MyISAM AUTO_INCREMENT=74 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_pages_files`
--

LOCK TABLES `tbl_pages_files` WRITE;
/*!40000 ALTER TABLE `tbl_pages_files` DISABLE KEYS */;
INSERT INTO `tbl_pages_files` VALUES (72,13),(72,14),(72,15);
/*!40000 ALTER TABLE `tbl_pages_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_users`
--

DROP TABLE IF EXISTS `tbl_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `url_role` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `login` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `salt` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `flg_active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_users`
--

LOCK TABLES `tbl_users` WRITE;
/*!40000 ALTER TABLE `tbl_users` DISABLE KEYS */;
INSERT INTO `tbl_users` VALUES (1,'root','Дмитрий','root','6e047c439ea6860ace82c6ab7df718de','32ae28982e674c71fb57a1235f880350','',1);
/*!40000 ALTER TABLE `tbl_users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-12-09 13:39:52
