-- MySQL dump 10.13  Distrib 5.5.11, for Linux (x86_64)
--
-- Host: localhost    Database: h1185_dbg_2_db
-- ------------------------------------------------------
-- Server version	5.5.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbl_banners`
--

DROP TABLE IF EXISTS `tbl_banners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_banners` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_image` varchar(255) NOT NULL,
  `id_sort` int(10) unsigned NOT NULL,
  `id_position` int(10) unsigned NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `link` varchar(255) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_banners`
--

LOCK TABLES `tbl_banners` WRITE;
/*!40000 ALTER TABLE `tbl_banners` DISABLE KEYS */;
INSERT INTO `tbl_banners` VALUES (23,'20',4,0,'Название представленного продукта или услуги','#','Краткое описание продукта, или услуги, или еще чего-нибудь. Пишется мелким шрифтом. Здесь писать много не надо.'),(25,'17',2,0,'Название представленного продукта','google.ru','Краткое описание продукта, или услуги, или еще чего-нибудь. Пишется мелким шрифтом. Здесь писать много не надо.');
/*!40000 ALTER TABLE `tbl_banners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_bug_messages`
--

DROP TABLE IF EXISTS `tbl_bug_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_bug_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_bug` int(10) unsigned NOT NULL,
  `id_user` int(10) unsigned NOT NULL,
  `time` int(10) unsigned NOT NULL,
  `text` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=111 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_bug_messages`
--

LOCK TABLES `tbl_bug_messages` WRITE;
/*!40000 ALTER TABLE `tbl_bug_messages` DISABLE KEYS */;
INSERT INTO `tbl_bug_messages` VALUES (103,34,41,1386654600,'Статус изменен на \"Готово\"'),(104,33,41,1386654609,'Статус изменен на \"Готово\"'),(105,35,1,1386655191,'Статус изменен на \"В работе\"'),(106,35,1,1386655205,'Нужно связаться с верстальщиком'),(107,35,1,1386655221,'Статус изменен на \"Готово\"'),(108,35,41,1386655261,'Статус изменен на \"Закрыто\"'),(109,34,41,1386655279,'Статус изменен на \"Закрыто\"'),(110,33,41,1386655297,'Статус изменен на \"Закрыто\"');
/*!40000 ALTER TABLE `tbl_bug_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_bugs`
--

DROP TABLE IF EXISTS `tbl_bugs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_bugs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `id_priority` int(10) unsigned NOT NULL,
  `id_state` int(10) unsigned NOT NULL,
  `description` text NOT NULL,
  `reply` text NOT NULL,
  `id_user` varchar(45) NOT NULL,
  `time_detected` int(10) unsigned NOT NULL,
  `time_done` int(10) unsigned NOT NULL,
  `id_type` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_bugs`
--

LOCK TABLES `tbl_bugs` WRITE;
/*!40000 ALTER TABLE `tbl_bugs` DISABLE KEYS */;
INSERT INTO `tbl_bugs` VALUES (33,'Убрать листалку','http://dbg2.deka-web.ru/contacts',0,30,'Убрать листалку с этой страницы. И сделать так, чтобы показ листалки на обычных страницах настраивался.','','41',1386619200,1386655297,0),(34,'Баннеры в правую колонку','http://dbg2.deka-web.ru/cp/banners/admin/admin',0,30,'','','41',1386619200,1386655279,1),(35,'Сделать резину','http://dbg2.deka-web.ru',1,30,'','','41',1386619200,1386655261,0),(36,'миниатюры плохо работают','http://dbg2.deka-web.ru',1,0,'','','41',1387137600,0,0),(37,'на витрине не краткое описание а название','http://dbg2.deka-web.ru',1,0,'','','41',1387137600,0,0);
/*!40000 ALTER TABLE `tbl_bugs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_feedback`
--

DROP TABLE IF EXISTS `tbl_feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_feedback` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tst_create` int(10) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `flg_new` tinyint(1) unsigned NOT NULL,
  `flg_phonecall` int(11) NOT NULL,
  `phone` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_feedback`
--

LOCK TABLES `tbl_feedback` WRITE;
/*!40000 ALTER TABLE `tbl_feedback` DISABLE KEYS */;
INSERT INTO `tbl_feedback` VALUES (17,1386576890,'Превед','tishurin@yandex.ru','',0,0,''),(18,1386577412,'Дмитрий','tishurin@yandex.ru','Мое сообщение - можно ли то-то',0,0,'123-23-23'),(19,1386577463,'Дмитрий','tishurin@yandex.ru','Мое сообщение - можно ли то-то',0,0,'123-23-23'),(20,1386577481,'Дмитрий','tishurin@yandex.ru','Мое сообщение - можно ли то-то',0,0,'123-23-23'),(21,1386577524,'Дмитрий','tishurin@yandex.ru','Мое сообщение - можно ли то-то',0,0,'123-23-23'),(22,1386579929,'Дмитрий','','',0,1,'926-355-96-83');
/*!40000 ALTER TABLE `tbl_feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_files`
--

DROP TABLE IF EXISTS `tbl_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_files` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `source` varchar(255) NOT NULL,
  `tst_upload` int(10) unsigned NOT NULL,
  `flg_folder` int(10) unsigned NOT NULL,
  `id_parent` int(10) unsigned NOT NULL,
  `flg_image` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=44 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_files`
--

LOCK TABLES `tbl_files` WRITE;
/*!40000 ALTER TABLE `tbl_files` DISABLE KEYS */;
INSERT INTO `tbl_files` VALUES (11,'160.jpg','6/52a56d280e89f',1386573096,0,0,1),(12,'bears-42.jpg','6/52a56fccb344d',1386573772,0,0,1),(13,'elephants-11.jpg','8/52a580841ac54',1386578052,0,0,1),(14,'elks-1.jpg','8/52a581ae5202a',1386578350,0,0,1),(15,'tigers-39.jpg','8/52a58208ccef5',1386578440,0,0,1),(16,'raccoons-7.jpg','8/52a58b622becb',1386580834,0,0,1),(17,'259.png','8/52a58d09ada98',1386581257,0,0,1),(18,'bears-9.jpg','a/52a6a36ce9714',1386652524,0,0,1),(19,'tigers-39.jpg','a/52a6a50237fa6',1386652930,0,0,1),(20,'52a58d09ada98_real.png','e/52a6e3383d4f3',1386668856,0,0,1),(21,'52a58d09ada98_real.png','e/52a6e3be9356b',1386668990,0,0,1),(22,'52a58d09ada98.png','e/52a6e3dd5392f',1386669021,0,0,1),(23,'52a58d09ada98_real.png','e/52a6e412d2e1d',1386669074,0,0,1),(24,'52a58d09ada98_real.png','e/52a6e4524415e',1386669138,0,0,1),(25,'52a58d09ada98_real.png','e/52a6e4d09ec06',1386669264,0,0,1),(26,'Новость 1-page-001.jpg','7/52ae7bd28c58b',1387166674,0,0,1),(27,'Новость2-page-001.jpg','7/52ae7cbe0b811',1387166910,0,0,1),(28,'Новость2-page-001.jpg','7/52ae7cdf92895',1387166943,0,0,1),(29,'Новость3-page-001.jpg','7/52ae7d5e833b1',1387167070,0,0,1),(30,'1.png','7/52ae7f5274837',1387167570,0,0,1),(31,'ds-endpoint-protection-advanced-suite(1).pdf','8/52ae81c68f587',1387168198,0,0,0),(32,'1.png','8/52ae820797ebc',1387168263,0,0,1),(33,'2.jpg','8/52ae845cbdeb0',1387168860,0,0,1),(34,'2.jpg','8/52ae85e713a4f',1387169255,0,0,1),(35,'1.jpg','8/52ae86d3df0a0',1387169491,0,0,1),(36,'1.jpg','8/52ae870379213',1387169539,0,0,1),(37,'2.jpg','8/52ae871a9d98a',1387169562,0,0,1),(38,'1.jpg','8/52ae872eedc64',1387169582,0,0,1),(39,'2.jpg','8/52ae87dbad8a6',1387169755,0,0,1),(40,'3.jpg','8/52ae888ec2819',1387169934,0,0,1),(41,'3.jpg','8/52ae8a2503daf',1387170341,0,0,1),(42,'4.jpg','8/52ae8b598f7b8',1387170649,0,0,1),(43,'4.jpg','8/52ae8b6a377b9',1387170666,0,0,1);
/*!40000 ALTER TABLE `tbl_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_pages`
--

DROP TABLE IF EXISTS `tbl_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_parent` int(10) unsigned NOT NULL,
  `id_sort` int(10) unsigned NOT NULL,
  `id_image` int(11) NOT NULL,
  `tst_create` int(10) unsigned NOT NULL,
  `tst_update` int(10) unsigned NOT NULL,
  `flg_public` int(10) unsigned NOT NULL,
  `flg_folder` int(10) unsigned NOT NULL,
  `url` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `template` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `description` text NOT NULL,
  `content` text NOT NULL,
  `areas` text NOT NULL,
  `flg_block_header` int(10) unsigned NOT NULL,
  `flg_block_text` int(10) unsigned NOT NULL,
  `flg_markdown` int(10) unsigned NOT NULL,
  `flg_menu` int(11) NOT NULL,
  `flg_index` int(11) NOT NULL,
  `flg_show_news` int(11) NOT NULL,
  `flg_show_slider` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=92 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_pages`
--

LOCK TABLES `tbl_pages` WRITE;
/*!40000 ALTER TABLE `tbl_pages` DISABLE KEYS */;
INSERT INTO `tbl_pages` VALUES (82,0,4,0,1386792000,1386825402,1,0,'partneri','Партнеры','','[default]','','','<p>\r\n	Раздел находится в разработке. Приносим свои извинения.\r\n</p>','',0,0,0,1,0,1,1),(83,69,4,0,1387137600,1387166998,1,0,'cistemi_predotvrasheniya_vtorjenii_mcafee_ips','Cистемы предотвращения вторжений McAfee IPS','','[default]','','Получен сертификат ФСТЭК России на производство систем предотвращения вторжений McAfee IPS','<p>\r\n	 <img src=\"/assets/files/7/52ae7cdf92895_page.jpg\" style=\"width: 221px; float: left; margin: 0px 10px 10px 0px;\" alt=\"\">Получен сертификат ФСТЭК России на производство систем предотвращения вторжений McAfee IPS\r\n</p>\r\n<p>\r\n	 Москва, Россия, 21 июня - Корпорация McAfee, ведущий разработчик продуктов в сфере сетевой безопасности, совместно со своим российским технологическим партнером ЗАО НПК «Абитон» объявила об окончании процесса сертификации производства систем предотвращения вторжений с функцией межсетевого экрана McAfee IPS по требованиям безопасности информации ФСТЭК России.\r\n</p>\r\n<p>\r\n	  Полученный сертификат ФСТЭК России № 2907 от 21.06.2013 удостоверяет, что система предотвращения вторжений McAfeeNetworkSecurityPlatformявляется программным  средством защиты информации, реализующим функции системы обнаружения вторжений по 5 классу защиты.\r\n</p>','',0,0,0,0,0,1,1),(69,0,10,0,1375214400,1387166309,1,1,'news','Новости','news','viewNews','','','','',0,0,0,1,0,1,1),(71,69,2,0,1375214400,1387167010,1,0,'vtoraya_novost','McAfee Total Protection for Endpoint сертифицирован ФСТЭК России','','[default]','','Компания ЗАО НПК «Абитон» сообщает об успешном завершении сертификации на соответствие требованиям ФСТЭК России пакета программ McAfee Total Protection for Endpoint','<p>\r\n	<img src=\"/assets/files/7/52ae7bd28c58b_page.jpg\" alt=\"\" style=\"float: left; margin: 0px 10px 10px 0px; width: 190px;\">Компания ЗАО НПК «Абитон» сообщает об успешном завершении сертификации на соответствие требованиям ФСТЭК России пакета программ McAfee Total Protection for Endpoint — программного средства защиты информации от несанкционированного доступа, реализующего функции антивирусной защиты, обнаружения и предотвращения вторжений, фильтрации пакетов и запросов на установление соединений.\r\n</p>\r\n<p>\r\n	     В рамках сертификации комплекта McAfee Total Protection for Endpoint были проведены испытания следующих продуктов: McAfee VirusScan\r\n</p>\r\n<p>\r\n	      Enterprise версии 8.8, McAfee Host Intrusion Prevention System версии 8.0, консольуправления McAfee ePolicy Orchestrator.\r\n</p>\r\n<p>\r\n	     В результате испытаний было подтверждено, что характеристики сертифицированного решения McAfee Total Protection for Endpoint соответствуют требованиям руководящего документа «Защита от несанкционированного доступа к информации. Часть 1. Программное обеспечение средств защиты информации. Классификация по уровню контроля отсутствия недекларированных возможностей» (Гостехкомиссия России, 1999) — по 4 уровню контроля и технических условий.\r\n</p>\r\n<p>\r\n	     «Этим сертификатом McAfee отмечает окончание первой волны сертификации, которая была начата российским представительством McAfee еще в 2010 году. Нами сертифицированы (с анализом исходного кода на отсутствие НДВ) наиболее критичные для защиты компоненты защиты конечных точек: ePO, AntiVirus, Host IPS, Host DLP. Во вторую волну, которая стартовала в 2012 году, включены продукты по направлению сетевой безопасности и управления безопасностью. Уже получен сертификат на McAfee IPS, начат процесс сертификации (с анализом исходного кода на отсутствие НДВ) WebGateway и SIEM. Все это является отражением нашей стратегии, направленной на инвестирование в развитие российского рынка, занимающего ключевую роль в регионе. Надеюсь, что теперь и наши партнеры, и наши заказчики смогут не нарушая регулятивных норм и требований, по достоинству оценить качество и надежность всего спектра наших продуктов и решений — решений от мирового лидера ИБ. На следующий год нами сейчас прорабатываются планы по дальнейшей сертификации нашей платформы. О результатах этого планирования и о том, какие продукты будут сертифицированы в 2014 — 2015 году, мы обязательно сообщим сообщим нашим партнерам и заказчикам — для нас очень важна репутация не только технологического лидера отрасли, но вендора предсказуемого и максимально информационно открытого», — отметил генеральный директор McAfee Россия Павел Эйгес.\r\n</p>','',0,0,0,0,0,1,1),(73,0,8,0,1386536400,1386825296,1,1,'products','Продукты','','[default]','','','','',0,0,0,1,0,1,1),(74,0,6,0,1386536400,1386571335,1,1,'services','Услуги','','[default]','','','','',0,0,0,1,0,1,1),(75,0,2,0,1386532800,1386826656,1,0,'contacts','Контакты','contacts','[default]','','','<p>\r\n	         Закрытое акционерное общество\r\n</p>\r\n<p>\r\n	         Научно-производственная компания\r\n</p>\r\n<p>\r\n	 <strong>«АБИТОН»</strong><strong></strong>\r\n</p>\r\n<p>\r\n	 <strong></strong>\r\n</p>\r\n<p>\r\n	         115280, Москва, ул. Автозаводская, 13/1\r\n</p>\r\n<p>\r\n	         тел.: (495) 974-04-56\r\n</p>\r\n<p>\r\n	         E-mail: abiton@abiton.org\r\n</p>\r\n<p>\r\n	<iframe width=\"630\" height=\"600\" frameborder=\"0\" scrolling=\"no\" marginheight=\"0\" marginwidth=\"0\" src=\"https://www.google.ru/maps?f=q&amp;source=s_q&amp;hl=ru&amp;geocode=&amp;q=115280,+%D0%9C%D0%BE%D1%81%D0%BA%D0%B2%D0%B0,+%D1%83%D0%BB.+%D0%90%D0%B2%D1%82%D0%BE%D0%B7%D0%B0%D0%B2%D0%BE%D0%B4%D1%81%D0%BA%D0%B0%D1%8F,+13%2F1&amp;aq=&amp;sll=55.749792,37.632495&amp;sspn=0.947556,2.705383&amp;ie=UTF8&amp;hq=&amp;hnear=%D0%90%D0%B2%D1%82%D0%BE%D0%B7%D0%B0%D0%B2%D0%BE%D0%B4%D1%81%D0%BA%D0%B0%D1%8F+%D1%83%D0%BB.,+13%2F1,+%D0%9C%D0%BE%D1%81%D0%BA%D0%B2%D0%B0,+%D0%B3%D0%BE%D1%80%D0%BE%D0%B4+%D0%9C%D0%BE%D1%81%D0%BA%D0%B2%D0%B0&amp;ll=55.705639,37.655929&amp;spn=0.003706,0.010568&amp;t=m&amp;z=14&amp;output=embed\">\r\n	</iframe>\r\n</p>\r\n<p>\r\n	<small><a href=\"https://www.google.ru/maps?f=q&amp;source=embed&amp;hl=ru&amp;geocode=&amp;q=115280,+%D0%9C%D0%BE%D1%81%D0%BA%D0%B2%D0%B0,+%D1%83%D0%BB.+%D0%90%D0%B2%D1%82%D0%BE%D0%B7%D0%B0%D0%B2%D0%BE%D0%B4%D1%81%D0%BA%D0%B0%D1%8F,+13%2F1&amp;aq=&amp;sll=55.749792,37.632495&amp;sspn=0.947556,2.705383&amp;ie=UTF8&amp;hq=&amp;hnear=%D0%90%D0%B2%D1%82%D0%BE%D0%B7%D0%B0%D0%B2%D0%BE%D0%B4%D1%81%D0%BA%D0%B0%D1%8F+%D1%83%D0%BB.,+13%2F1,+%D0%9C%D0%BE%D1%81%D0%BA%D0%B2%D0%B0,+%D0%B3%D0%BE%D1%80%D0%BE%D0%B4+%D0%9C%D0%BE%D1%81%D0%BA%D0%B2%D0%B0&amp;ll=55.705639,37.655929&amp;spn=0.003706,0.010568&amp;t=m&amp;z=14\" style=\"color:#0000FF;text-align:left\">Просмотреть увеличенную карту</a></small>\r\n</p>\r\n<p>\r\n	        Вы можете связаться с нами воспользовавшись формой обратной связи:\r\n</p>','',0,0,0,1,0,1,1),(78,0,12,0,1386532800,1387172301,1,0,'index','Главная страница','index','[default]','','','<h1>О компании</h1>\r\n<p>\r\n	Данный раздел находится в разработке.\r\n</p>','',0,0,0,0,0,1,1),(85,73,2,0,1387137600,1387167351,1,1,'programmnoe_obespechenie','Программное обеспечение','','[default]','','','','',0,0,0,1,0,1,1),(86,73,4,0,1387137600,1387169817,1,1,'apparatnie_sredstva','Комплексные решения','','[default]','','','','',0,0,0,1,0,1,1),(87,85,2,38,1387137600,1387171131,1,0,'mcafee_endpoint_protection__advanced_suite','McAfee Endpoint Protection — Advanced Suite','','[default]','','Защита от атак «нулевого дня» и помощь в обеспечении соответствия законодательным требованиям','<h2><img src=\"/assets/files/7/52ae7f5274837_page.jpg\" style=\"width: 219px; float: left; margin: 0px 10px 10px 0px; cursor: nw-resize;\" alt=\"\">Защита от атак «нулевого дня» и помощь в обеспечении соответствия законодательным требованиям</h2>\r\n<p>\r\n	         Решение McAfee получило максимально возможное количество баллов среди продуктов для защиты от средств использования уязвимостей «нулевого дня» и от попыток обхода защиты. См. NSSLabsCorporateAV/EPPComparativeAnalysis, ExploitEvasionDefenses(Сравнительный анализ корпоративных продуктов для защиты от вирусов и попыток обхода защиты, проведенный компанией NSS Labs: средства защиты от попыток обхода защиты).\r\n</p>\r\n<h2> Ключевые преимущества</h2>\r\n<ul>\r\n	<li>Защищает устройства с Microsoft Windows, Mac и Linux от сетевых и системных угроз, угроз, нацеленных на данные и электронную почту, а также от рисков нарушения соответствия нормативным требованиям.</li>\r\n	<li>Объединяет усилия по защите конечных точек и данных в едином интегрированном решении от единого производителя, обеспечивая при этом более надежную защиту при меньших затратах.</li>\r\n	<li>Мгновенно включает усиленную защиту с помощью простой и эффективной среды централизованного управления.</li>\r\n</ul>\r\n<h2>McAfee устанавливает отраслевой стандарт</h2>\r\n<ul>\r\n	<li>Решение McAfee становится лидером рейтинга компании Gartner в категории средств защиты конечных точек и мобильных данных</li>\r\n	<li>Первое решение, которое позволяет с единой консоли управлять широким диапазоном защитных продуктов, включая решения для защиты конечных точек, сети, данных, электронной почты и веб-трафика</li>\r\n	<li>Первое решение для управления безопасностью конечных точек с единым агентом и единой консолью</li>\r\n	<li>Первый продукт, позволивший создать единую платформу управления защитой конечных точек и нормативно- правовым соответствием</li>\r\n	<li>Первый продукт, позволивший управлять как решениями McAfee, так и решениями сторонних поставщиков</li>\r\n	<li>Первое решение, позволившее объединить средства аудита и применения политик в единый механизм</li>\r\n	<li>Первое решение, сочетающее в себе безопасность конечных точек и защиту данных в рамках единого, по-настоящему интегрированного комплекта </li>\r\n</ul>','',0,0,0,0,1,1,1),(84,69,6,0,1387137600,1387167084,1,0,'programmnoe_reshenie_mcafee_host_dlp','Программное решение McAfee Host DLP','','[default]','','Получен сертификат ФСТЭК России на программное решение McAfee Host DLP','<p>\r\n	<img src=\"/assets/files/7/52ae7d5e833b1_page.jpg\" alt=\"\" style=\"float: left; margin: 0px 10px 10px 0px; width: 226px;\">Получен сертификат ФСТЭК России на программное решение McAfee Host DLP\r\n</p>\r\n<p>\r\n	Компания McAfee анонсировала программное решение McAfee Host DLP, которое является средством комплексной защиты данных от несанкционированной утечки или кражи, а также позволяет анализировать потоки переноса данных с/на рабочую станцию по таким каналам, как электиронная почта, интернет, съемные носители и т.п.<br>\r\n	 McAfee Host DLP обеспечивает централизованное управление всей системой с единой консоли, позволяя повысить безопасность рабочих станций.<br>\r\n	 В рамках сертификации комплекта «McAfee Host DLP» были проведены испытания на соответствие техническим условиям и отсутствие недекларированных возможностей партии из 300 экземпляров следующих программных продуктов:<br>\r\n	 «McAfee ePolicy Orchestrator 4.5» (обеспечивает управление программным продуктом );«McAfee Host DLP 9.1» (обеспечивает контроль за переносом и защиту данных на рабочих станций).<br>\r\n	 В результате испытаний было доказано, что сертифицированный пакет McAfee Host DLP является средством защиты от несанкционированной передачи ( вывода) информации ограниченного доступа, не содержащей сведений, составляющих госудаственную тайну, из защищенного сегмента информационной сети на основе анализа смыслового содержания информации и соответствует требованиям руководящего документа «Защита от несанкционированного доступа к информации. Часть 1. Програмнное обеспечение средства защиты информации. Классификация по уровню контроля отсутствия недекларированных возможностей» (Гостехкомиссия России, 1999) по четвертому уровню контроля и технических условий.<br>\r\n	 Сертификат соответствия № 2736 был выдан Федеральной службой по техническому и экспортному контролю 23 октября 2012 года.<br>\r\n	 «С момента открытия офиса в России компания McAfee уделяет самое пристальное внимание вопросам сертификации своих продуктов. Имея в наличии широчайший спектр продуктов и решений, наша компания последовательно движется к полностью сертифицированному портфелю решений\", - отметил генеральный директор McAfee Россия Павел Эйгес . – «Получение сертификата на Host DLP – очередной шаг в этом направлении\r\n</p>','',0,0,0,0,0,1,1),(91,86,6,43,1387137600,1387171143,1,0,'mcafee_web_gateway','​McAfee Web Gateway','','[default]','','Безопасность. Контроль. Быстродействие. McAfee Web Gateway — лучший в отрасли уровень защиты. Являясь лучшим устройством защиты от вредоносных программ*, McAfee Web Gateway использует технологию поведенческого анализа с помощью модуля McAfee Gateway Anti-Malware Engine. ','<h2><img src=\"/assets/files/8/52ae8b598f7b8_page.jpg\" alt=\"\" style=\"float: left; margin: 0px 10px 10px 0px; width: 256px;\">Безопасность. Контроль. Быстродействие. McAfee Web Gateway — лучший в отрасли уровень защиты </h2>\r\n<p>\r\n	    Являясь лучшим устройством защиты от вредоносных программ*, McAfee Web Gateway использует технологию поведенческого анализа с помощью модуля McAfee Gateway Anti-Malware Engine. Патентная заявка на эту разработку находится на стадии рассмотрения. Средства проактивного поведенческого анализа позволяют в реальном времени отфильтровывать имеющееся в трафике вредоносное содержимое. Сканируя активное содержимое веб-страницы, имитируя и анализируя его поведение, а также прогнозируя его дальнейшие действия, McAfee Web Gateway обеспечивает проактивную защиту от угроз «нулевого дня» и целенаправленных атак по мере их появления.\r\n</p>\r\n<ul>\r\n	<li>Сертифицировано по стандартам Common Criteria уровня EAL2+ и FIPS 140-2 уровня 2</li>\r\n	<li>Четвертый год подряд лидирует в отчете консалтинговой компании Gartner «Магический квадрант» в сегменте веб-шлюзов</li>\r\n	<li>Лидер рейтинга Forrester Wave за 2009 г. в категории «Фильтрация веб-содержимого»</li>\r\n	<li>Первое место среди решений по защите от вредоносных программ (AV-Test.org)</li>\r\n	<li>Два года подряд самая большая доля рынка продаж аппаратных веб-шлюзов (IDC)</li>\r\n	<li>«Ведущий игрок» согласно анализу, проводимому аналитической фирмой RadicatiGroup</li>\r\n	<li>Победитель теста ClearChoiceжурнала <em>Network World </em>в 2009 г.</li>\r\n	<li>Премия читательских симпатий 2009 г. журнала <em>Information Security</em></li>\r\n	<li>Лучшее решение 2010 г. для защиты от вредоносных программ по версии журнала <em>SC Magazine</em></li>\r\n</ul>','',0,0,0,0,1,1,1),(90,86,4,41,1387137600,1387170864,1,0,'mcafee_network_security_platform','McAfee Network Security Platform','','[default]','','Беспрецедентно «умный» подход к сетевой безопасности. Платформа McAfee® Network Security Platform — уникальное решение интеллектуальной защиты, предназначенное для обнаружения и блокирования изощренных сетевых угроз.','<h2><img src=\"/assets/files/8/52ae888ec2819_page.jpg\" alt=\"\" style=\"float: left; margin: 0px 10px 10px 0px; width: 241px;\">Беспрецедентно «умный» подход к сетевой безопасности</h2>\r\n<p>\r\n	  Платформа McAfee® Network Security Platform — уникальное решение интеллектуальной защиты, предназначенное для обнаружения и блокирования изощренных сетевых угроз. Использование усовершенствованных методов обнаружения угроз безопасности дает ему возможность не ограничивается простым сопоставлением образцов и отражать скрытые атаки с чрезвычайно высокой степенью точности.\r\n</p>\r\n<h2>Ключевые преимущества</h2>\r\n<p>\r\n	  Беспрецедентный уровень предотвращения угроз\r\n</p>\r\n<ul>\r\n	<li>Архитектура следующего поколения</li>\r\n	<li>Усовершенствованныефункции обнаружения бот-сетей</li>\r\n	<li>Анализ поведения </li>\r\n</ul>\r\n<p>\r\n	  Комплексная защита от вредоносных программ\r\n</p>\r\n<ul>\r\n	<li>Усовершенствованные функции анализа вредоносных программ без использования сигнатур</li>\r\n	<li>Панель для проведения расследований по вредоносным программам</li>\r\n	<li>Предсказательная модель обнаружения вредоносных программ с помощью McAfee GTI</li>\r\n</ul>\r\n<p>\r\n	  Security Connected\r\n</p>\r\n<ul>\r\n	<li>Контекстуальная информация об узлах в режиме реального времени, собираемая с помощью программного обеспечения McAfee ePO</li>\r\n	<li>McAfee GTI</li>\r\n	<li>Встроенные аналитические функции для проведения компьютерно- технических экспертиз</li>\r\n</ul>\r\n<p>\r\n	  Производительность и доступность\r\n</p>\r\n<ul>\r\n	<li>Пропускная способность до 20 Гбит/с</li>\r\n	<li>Лучшая в отрасли готовность</li>\r\n	<li>Высокая степень доступности в режиме «активный-активный»</li>\r\n</ul>\r\n<p>\r\n	  Интеллектуальное управление безопасностью\r\n</p>\r\n<ul>\r\n	<li>Масштабируемые функции управления через веб-консоль</li>\r\n	<li>Автоматическая приоритезация оповещений</li>\r\n	<li>Рабочие процессы основаны на методе «последовательного раскрытия»</li>\r\n</ul>\r\n<p>\r\n	  Информированность и контроль\r\n</p>\r\n<ul>\r\n	<li>Идентификация приложений</li>\r\n	<li>Идентификация пользователей</li>\r\n	<li>Идентификация устройств</li>\r\n</ul>','',0,0,0,0,0,1,1),(89,86,2,39,1387137600,1387171155,1,0,'mcafee_email_gateway','McAfee Email Gateway','','[default]','','Полная защита корпоративной электронной почты. McAfee Email Gateway объединяет в себе множество комплексных средств защиты и шифрования на единой платформе и по одной цене.','<h2><img src=\"http://dbg2.deka-web.ru/assets/files/8/52ae845cbdeb0_page.jpg\" alt=\"\" style=\"float: left; margin: 0px 10px 10px 0px; width: 265px;\">Полная защита корпоративной электронной почты</h2>\r\n<p>\r\n	    McAfee Email Gateway объединяет в себе комплексные средства защиты от угроз во входящем трафике, средства предотвращения утечек данных в исходящем трафике, усовершенствованные механизмы обеспечения нормативно-правового соответствия, улучшенные средства шифрования электронной почты, средства повышения быстродействия, ведения отчетности и упрощенного администрирования, и все это — на единой платформе и по одной цене. Благодаря объединению информации о локальной сетевой активности с данными проверки репутации глобальных доменов McAfee Global Threat Intelligence™ (McAfee GTI™), обеспечивается наиболее полная защита от входящих угроз, нежелательной почты и вредоносных программ. Интеллектуальные технологии проверки содержимого, методы многократного шифрования и детальная обработка сообщений на основе политик предотвращают потерю исходящих данных и упрощают процесс обеспечения нормативно- правового соответствия. Администраторы имеют гибкие средства создания политик в соответствии с задачами своих предприятий, тем самым повышая производительность решений. Полная интеграция с программным обеспечением McAfee® ePolicy Orchestrator® (McAfee ePO™) дает возможность полного управления решением. Функции ведения журналов и отчетности корпоративного класса помогают упростить процессы администрирования и обеспечения нормативно-правового соответствия, позволяя существенно сократить расходы.\r\n</p>\r\n<h2>Ключевые преимущества</h2>\r\n<p>\r\n	  McAfee Email Gateway является наиболее масштабируемым, гибким и многофункциональным решением для защиты электронной почты из имеющихся на рынке. К числу его основных функций относятся DLP, централизованное управление, кластеризация и функция шифрования электронной почты, за которую не взимается дополнительная плата.\r\n</p>\r\n<ul>\r\n	<li>Выбор форм-факторов развертывания, включая стандартные аппаратные устройства, виртуальные устройства и блейд-серверы</li>\r\n	<li>Высоко масштабируемый диспетчер карантина, способный обеспечить поддержку 200 000 конечных пользователей</li>\r\n	<li>Поддержка IPv6 и CAC</li>\r\n</ul>\r\n<p>\r\n	  Лидер на рынке средств защиты\r\n</p>\r\n<ul>\r\n	<li>Проверка содержимого входящей и исходящей электронной почты с помощью технологии McAfee DLP</li>\r\n	<li>Защита от нежелательных сообщений, вредоносных программ и фишинга</li>\r\n	<li>Технология McAfee для оценки репутации отправителей, сообщений и сетей</li>\r\n</ul>\r\n<p>\r\n	  Передовая высокоскоростная архитектура\r\n</p>\r\n<ul>\r\n	<li>Асинхронная проверка содержимого на основе анализа памяти</li>\r\n	<li>Увеличение быстродействия примерно в два раза по сравнению с предыдущей версией за счет использования интегрированных средств кластеризации и выравнивания нагрузки</li>\r\n</ul>\r\n<p>\r\n	  Продуманные средства управления и применения политик\r\n</p>\r\n<ul>\r\n	<li>Ненавязчивый, интуитивно понятный интерфейс; наличие мастеров установки и конфигурации</li>\r\n	<li>Наличие политик для входящих и исходящих сообщений</li>\r\n	<li>Возможность избирательного применения политик благодаря интеграции с протоколами DAP и LDAP (протоколы доступа к каталогу)</li>\r\n	<li>Шифрование на основе политик в качестве одной из основных функций: с помощью протокола безопасности транспортного уровня (transport layer security — TLS), модели push/pull</li>\r\n	<li>Получение и просмотр зашифрованных сообщений на мобильных устройствах</li>\r\n	<li>Почтовый веб-клиент, поддерживающий фирменную настройку</li>\r\n	<li>Составление отчетов в режиме реального времени: быстро, гибко, интерактивно и наглядно</li>\r\n	<li>Информативные интерактивные панели мониторинга и функции централизованного управления и отчетности благодаря использованию программного обеспечения McAfee ePO</li>\r\n	<li>Поиск сообщений по всем кластерам</li>\r\n	<li>Подробный журнал обмена сообщениями</li>\r\n</ul>','',0,0,0,0,1,1,1);
/*!40000 ALTER TABLE `tbl_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_pages_files`
--

DROP TABLE IF EXISTS `tbl_pages_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_pages_files` (
  `id_page` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_file` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id_page`,`id_file`)
) ENGINE=MyISAM AUTO_INCREMENT=82 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_pages_files`
--

LOCK TABLES `tbl_pages_files` WRITE;
/*!40000 ALTER TABLE `tbl_pages_files` DISABLE KEYS */;
INSERT INTO `tbl_pages_files` VALUES (71,26),(74,27),(75,28),(78,31),(79,33),(80,40),(81,42);
/*!40000 ALTER TABLE `tbl_pages_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_users`
--

DROP TABLE IF EXISTS `tbl_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `url_role` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `login` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `salt` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `flg_active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=43 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_users`
--

LOCK TABLES `tbl_users` WRITE;
/*!40000 ALTER TABLE `tbl_users` DISABLE KEYS */;
INSERT INTO `tbl_users` VALUES (1,'root','Дмитрий','root','6e047c439ea6860ace82c6ab7df718de','32ae28982e674c71fb57a1235f880350','',1),(41,'root','Виталий','vvt','c4510c1b4a0156f462f49aaf99f5538b','f6aded2be46c3e603d22f7702a82a1c8','',1),(42,'administrator','abiton','abiton','ee887c837f99f0f27a5444c53e6d42fd','d0378f3f1cf4337a09a07242cbf8b0a8','abiton@yandex.ru',1);
/*!40000 ALTER TABLE `tbl_users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-12-16 10:38:24
